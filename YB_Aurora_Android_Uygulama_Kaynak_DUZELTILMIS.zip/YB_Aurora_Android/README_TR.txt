YB AURORA — ANDROID UYGULAMA KAYNAK PROJESİ
================================================

Bu paket Android Studio'da açılmak ve APK olarak derlenmek üzere hazırlanmış yerel Android uygulama kaynak kodudur; web önizlemesi değildir.

İÇERİK
- YB Aurora koyu cam / elektrik mavisi / altın temalı Android arayüzü
- Ana ekran, Veron, Vera, kontrol merkezi ve ayarlar
- Fener: kamera izni verildiğinde gerçek Android fenerini açıp kapatır
- Wi-Fi, Bluetooth, ekran, ses ve uçak modu için Android sistem ayarlarına geçiş
- Telefon arama ekranına geçiş ve telefondaki bazı uygulamaları açma
- Türkçe ses tanıma isteği (cihazda bir konuşma tanıma servisi bulunmasına bağlı)

DERLEME
1. Bilgisayarda Android Studio kurun.
2. Bu ZIP dosyasını çıkarın.
3. Android Studio > Open > çıkarılan YB_Aurora_Android klasörünü seçin.
4. Gradle senkronizasyonunun tamamlanmasını bekleyin.
5. Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Üretilen APK'yı Android telefonunuza aktarın ve kurun.

ÖNEMLİ SINIRLAR
- Bu ortamda Android SDK/Gradle kurulu olmadığından hazır APK derlenemedi.
- Veron, Ayarlar ekranına girilen API sunucu adresine sohbet mesajı ve konuşma geçmişi gönderir. Sunucu protokolünün bu uygulamanın beklediği JSON biçimiyle uyumlu olması gerekir.
- Vera gelen arama arayüzü için Android'de varsayılan telefon uygulaması rolü gerekir. Ayarlar ekranında isteğe bağlı otomatik yanıt açılabilir. Vera'nın TTS selamı bu cihazda duyulur; standart Android API'leri bu sesi karşı tarafın telefon hattına aktarmayı veya arayanın sesini serbestçe kaydetmeyi sağlamaz. Bu nedenle aramayla tam sesli yapay zekâ görüşmesi bu pakette desteklenmez.
- HTML prototipinden farklı olarak bu paket yerel Android kaynak projesidir; yine de tamamlanmış APK veya bütün özellikleri etkin nihai ürün olarak değerlendirilmemelidir.
