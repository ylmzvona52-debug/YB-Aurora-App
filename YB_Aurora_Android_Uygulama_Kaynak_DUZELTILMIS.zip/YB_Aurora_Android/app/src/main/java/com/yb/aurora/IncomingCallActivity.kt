package com.yb.aurora

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.telecom.Call
import android.speech.tts.TextToSpeech
import java.util.Locale

/** Minimal custom incoming-call UI. The user's phone/carrier still controls call audio routing. */
class IncomingCallActivity : Activity() {
    private var tts: TextToSpeech? = null
    private val blue = Color.rgb(51,198,255)
    private val gold = Color.rgb(236,184,88)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(3,8,17)
        window.navigationBarColor = Color.rgb(3,8,17)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 36)
            setBackgroundColor(Color.rgb(3,8,17))
        }
        root.addView(TextView(this).apply {
            text = "ϟ  V E R A"
            textSize = 30f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setTextColor(gold)
        })
        root.addView(TextView(this).apply {
            text = "GELEN ARAMA"
            textSize = 17f; gravity = Gravity.CENTER; setTextColor(blue)
            setPadding(0, 28, 0, 10)
        })
        root.addView(TextView(this).apply {
            text = "Vera gelen aramayı yönetir. Yanıtlandıktan sonra bu cihazda sesli selam verir. Android, bu sesi karşı tarafa aktarmayı standart uygulamalara açmaz."
            textSize = 15f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            setPadding(0, 0, 0, 30)
        })
        root.addView(Button(this).apply {
            text = "ARAMAYI YANITLA"
            setOnClickListener {
                val call = CurrentAuroraCall.call
                if (call != null && call.state == Call.STATE_RINGING) {
                    call.answer(android.telecom.VideoProfile.STATE_AUDIO_ONLY)
                    sayGreeting()
                } else if (call != null && call.state == Call.STATE_ACTIVE) {
                    sayGreeting()
                }
            }
        }, LinearLayout.LayoutParams(-1, 58))
        root.addView(Button(this).apply {
            text = "ARAMAYI REDDET"
            setOnClickListener {
                CurrentAuroraCall.call?.disconnect()
                finish()
            }
        }, LinearLayout.LayoutParams(-1, 58))
        setContentView(root)
        tts = TextToSpeech(this) { status -> if (status == TextToSpeech.SUCCESS) tts?.language = Locale("tr", "TR") }
    }

    private var greetingSpoken = false

    private fun sayGreeting() {
        // TTS is local to this device. Standard Android APIs do not inject it into caller uplink audio.
        if (greetingSpoken) return
        greetingSpoken = true
        tts?.speak("Merhaba, ben Vera. Arama yanıtlandı. Telefon sahibi şu anda görüşmeye katılabilir.", TextToSpeech.QUEUE_FLUSH, null, "vera_call_greeting")
    }

    override fun onDestroy() {
        tts?.stop(); tts?.shutdown(); tts = null
        super.onDestroy()
    }
}
