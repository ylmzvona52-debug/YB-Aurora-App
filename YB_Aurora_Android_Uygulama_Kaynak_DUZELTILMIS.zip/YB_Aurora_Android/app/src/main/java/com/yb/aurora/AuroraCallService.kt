package com.yb.aurora

import android.telecom.Call
import android.telecom.InCallService
import android.content.Intent
import android.os.Handler
import android.os.Looper

/** Gelen çağrı arayüzü. Android'de varsayılan telefon uygulaması rolü verilmelidir. */
class AuroraCallService : InCallService() {
    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        CurrentAuroraCall.call = call
        if (call.state == Call.STATE_RINGING) {
            val autoAnswer = getSharedPreferences("aurora", MODE_PRIVATE)
                .getBoolean("auto_answer", false)
            if (autoAnswer) {
                // Kullanıcının Ayarlar'da ayrıca açtığı isteğe bağlı özellik.
                Handler(Looper.getMainLooper()).postDelayed({
                    if (CurrentAuroraCall.call === call && call.state == Call.STATE_RINGING) {
                        try {
                            call.answer(android.telecom.VideoProfile.STATE_AUDIO_ONLY)
                        } catch (_: Exception) { }
                    }
                }, 700)
            }
            val intent = Intent(this, IncomingCallActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            }
            try { startActivity(intent) } catch (_: Exception) { }
        }
    }

    override fun onCallRemoved(call: Call) {
        if (CurrentAuroraCall.call === call) CurrentAuroraCall.call = null
        super.onCallRemoved(call)
    }
}

object CurrentAuroraCall {
    @Volatile var call: Call? = null
}
