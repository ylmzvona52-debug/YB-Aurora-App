package com.yb.aurora

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.RecognitionListener
import android.speech.tts.TextToSpeech
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.io.OutputStreamWriter
import android.app.Activity
import android.app.role.RoleManager
import android.os.Build
import android.content.Intent
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.graphics.drawable.GradientDrawable
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(3, 8, 17)
    private val panel = Color.rgb(8, 19, 33)
    private val blue = Color.rgb(51, 198, 255)
    private val gold = Color.rgb(236, 184, 88)
    private var flashlightOn = false
    private var cameraId: String? = null
    private lateinit var root: LinearLayout
    private var apiUrl = ""
    private var apiKey = ""
    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var pendingInput: EditText? = null
    private var pendingAnswer: TextView? = null
    private var pendingIsVera = false
    private var pendingColor: Int = 0
    private var isListening = false
    private val conversation = mutableListOf<JSONObject>()
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        try {
            val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            cameraId = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
        } catch (_: Exception) {}
        apiUrl = getSharedPreferences("aurora", 0).getString("url", "") ?: ""
        apiKey = getSharedPreferences("aurora", 0).getString("key", "") ?: ""
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val result = tts?.setLanguage(Locale("tr", "TR"))
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    Toast.makeText(this, "Türkçe ses paketi bu cihazda desteklenmiyor.", Toast.LENGTH_LONG).show()
                }
            }
        }
        showHome()
    }

    private fun base(title: String, subtitle: String? = null): LinearLayout {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(14))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(2, 7, 15), Color.rgb(7, 18, 32), Color.rgb(3, 8, 17)))
        }
        val sc = ScrollView(this)
        val inner = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0,0,0,dp(12)) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val mark = TextView(this).apply { text = "Ⅴ  YB"; textSize = 21f; setTextColor(gold); setPadding(0,0,dp(12),0) }
        header.addView(mark)
        val spacer = Space(this); header.addView(spacer, LinearLayout.LayoutParams(0,1f))
        header.addView(TextView(this).apply { text = "◉  ◉  ▰"; textSize = 13f; setTextColor(blue) })
        inner.addView(header)
        inner.addView(TextView(this).apply {
            text = title; textSize = 28f; setTextColor(Color.WHITE); setPadding(0,dp(20),0,dp(2)); typeface = android.graphics.Typeface.create("sans-serif-light",0)
        })
        if (subtitle != null) inner.addView(TextView(this).apply { text=subtitle; textSize=13f; setTextColor(0xff9fb6cc.toInt()); setPadding(0,0,0,dp(14)) })
        val line = View(this).apply { setBackgroundColor(0x5537c8ff); layoutParams=LinearLayout.LayoutParams(-1,dp(1)) }
        inner.addView(line)
        sc.addView(inner)
        root.addView(sc, LinearLayout.LayoutParams(-1,0,1f))
        val nav = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER; setPadding(0,dp(10),0,0) }
        listOf("⌂" to "Ana", "◉" to "Veron", "ϟ" to "Vera", "▦" to "Kontrol", "⚙" to "Ayarlar").forEach { (ic, label) ->
            nav.addView(Button(this).apply {
                text="$ic\n$label"; textSize=10f; setTextColor(if(label=="Vera") gold else blue)
                background = rounded(panel, blue, 1)
                setOnClickListener { when(label) { "Ana"->showHome(); "Veron"->showAssistant(false); "Vera"->showAssistant(true); "Kontrol"->showControl(); else->showSettings() } }
            }, LinearLayout.LayoutParams(0,dp(54),1f).apply { setMargins(dp(3),0,dp(3),0) })
        }
        root.addView(nav)
        setContentView(root)
        return inner
    }

    private fun section(parent: LinearLayout, title: String) {
        parent.addView(TextView(this).apply { text=title; textSize=17f; setTextColor(gold); setPadding(0,dp(18),0,dp(8)) })
    }
    private fun card(parent: LinearLayout, title: String, detail: String, color: Int = blue, action: (() -> Unit)? = null) {
        val box = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(14),dp(12),dp(14),dp(12)); background=rounded(panel,color,1) }
        box.addView(TextView(this).apply { text=title; textSize=16f; setTextColor(Color.WHITE) })
        box.addView(TextView(this).apply { text=detail; textSize=12f; setTextColor(0xffa8bed1.toInt()); setPadding(0,dp(4),0,0) })
        if(action!=null) box.setOnClickListener { action() }
        val lp=LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,dp(5),0,dp(5)); parent.addView(box,lp)
    }
    private fun pill(parent: LinearLayout, text: String, color: Int=blue, action: ()->Unit) {
        parent.addView(Button(this).apply { this.text=text; textSize=13f; setTextColor(color); background=rounded(panel,color,1); setOnClickListener { action() } },
            LinearLayout.LayoutParams(-1,dp(48)).apply { setMargins(0,dp(4),0,dp(4)) })
    }

    private fun showHome() {
        val p=base("22:45", "17 Ekim • YB AURORA  /  Gece sürüş modu")
        p.addView(TextView(this).apply {
            text="        ✦           ☾\n\n      ╱╲   ✧   ╱╲\n   ╱╲╱  ╲____╱  ╲╱╲\n      ━━━━━━━━━━━\n       ◉  YOL  ◉\n\n   YOL, VARIŞTAN DAHA DEĞERLİDİR.\n        Çünkü yolda insan kendini bulur."
            gravity=Gravity.CENTER; textSize=17f; setTextColor(0xffd5eaff.toInt()); setPadding(0,dp(14),0,dp(18))
        })
        val orb=TextView(this).apply {
            text="◉\nV E R O N\n\nMavi ışıklı ana asistan"; gravity=Gravity.CENTER; textSize=19f; setTextColor(blue)
            background=rounded(Color.rgb(5,22,40),blue,2); setPadding(dp(12),dp(18),dp(12),dp(18))
            setOnClickListener { showAssistant(false) }
        }
        p.addView(orb,LinearLayout.LayoutParams(-1,dp(142)).apply { setMargins(0,dp(5),0,dp(5)) })
        val v=TextView(this).apply {
            text="ϟ  V E R A\nAltın ışıklı hızlı asistan"; gravity=Gravity.CENTER; textSize=17f; setTextColor(gold)
            background=rounded(Color.rgb(28,20,8),gold,2); setPadding(dp(10),dp(12),dp(10),dp(12))
            setOnClickListener { showAssistant(true) }
        }
        p.addView(v,LinearLayout.LayoutParams(-1,dp(92)).apply { setMargins(0,dp(5),0,dp(12)) })
        section(p,"UYGULAMALAR")
        val apps= listOf("☎  Telefon" to "Telefon uygulamasını aç", "◉  Chrome" to "Chrome'u aç", "◎  Kamera" to "Kamera'yı aç", "▧  Galeri" to "Fotoğrafları aç", "◉  WhatsApp" to "WhatsApp sohbet görünümü", "▤  Mesajlar" to "Mesajlar", "♫  Müzik" to "Müzik")
        apps.forEach { (a,d) -> card(p,a,d) { launchApp(a) } }
        pill(p,"KONTROL MERKEZİ",blue) { showControl() }
    }

    private fun showControl() {
        val p=base("Kontrol Merkezi","3. sürüm düzeni • Sistem izinlerine göre çalışır")
        section(p,"BİLDİRİMLER")
        card(p,"Veron","Ana asistan hazır • Mavi sistem",blue) { showAssistant(false) }
        card(p,"Vera","Hızlı komutlar • Altın sistem",gold) { showAssistant(true) }
        card(p,"WhatsApp","Uygulama sohbetlerine geçiş",0xff42d9b5.toInt()) { launchApp("WhatsApp") }
        section(p,"TELEFON ARAÇLARI")
        pill(p, if(flashlightOn) "☼  FENERİ KAPAT" else "☼  FENERİ AÇ", gold) { toggleFlashlight() }
        pill(p,"◉  Wi-Fi ayarları",blue) { startActivity(Intent(android.provider.Settings.ACTION_WIFI_SETTINGS)) }
        pill(p,"ϟ  Bluetooth ayarları",blue) { startActivity(Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS)) }
        pill(p,"▰  Ekran / parlaklık ayarları",blue) { startActivity(Intent(android.provider.Settings.ACTION_DISPLAY_SETTINGS)) }
        pill(p,"◐  Ses ayarları",blue) { startActivity(Intent(android.provider.Settings.ACTION_SOUND_SETTINGS)) }
        pill(p,"✈  Uçak modu ayarları",blue) { startActivity(Intent(android.provider.Settings.ACTION_AIRPLANE_MODE_SETTINGS)) }
        card(p,"Not","Android güvenliği nedeniyle bazı sistem anahtarları doğrudan değiştirilemez; ilgili sistem ayarı açılır.",gold)
    }

    private fun showAssistant(isVera: Boolean) {
        val c = if (isVera) gold else blue
        val p = base(if (isVera) "VERA" else "VERON", if (isVera) "Hızlı asistan • sesli komutlar" else "Ana asistan • sesli sohbet ve analiz")
        p.addView(TextView(this).apply {
            text = if (isVera) "ϟ" else "◉"
            gravity = Gravity.CENTER
            textSize = 68f
            setTextColor(c)
            background = rounded(panel, c, 2)
            setPadding(0, dp(8), 0, dp(8))
        }, LinearLayout.LayoutParams(-1, dp(118)).apply { setMargins(0, dp(14), 0, dp(12)) })

        val answer = TextView(this).apply {
            text = if (isVera) "Vera hazır. Mikrofonla konuşabilir veya komut yazabilirsin." else "Veron hazır. Mesajını yazabilir ya da mikrofonla konuşabilirsin."
            setTextColor(Color.WHITE); textSize = 15f; setPadding(dp(10), dp(10), dp(10), dp(10))
            background = rounded(panel, c, 1)
        }
        p.addView(answer)
        val input = EditText(this).apply {
            hint = "Buraya yaz veya mikrofonu kullan…"
            setHintTextColor(0xff8ba2b9.toInt()); setTextColor(Color.WHITE); setSingleLine(false)
            background = rounded(panel, c, 1); setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        p.addView(input, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(8), 0, dp(8)) })

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(Button(this).apply {
            text = "Gönder"; setTextColor(c); background = rounded(panel, c, 1)
            setOnClickListener { sendMessage(input.text.toString().trim(), isVera, answer, c) }
        }, LinearLayout.LayoutParams(0, dp(48), 1f))
        row.addView(Button(this).apply {
            text = "🎙 Konuş"; setTextColor(c); background = rounded(panel, c, 1)
            setOnClickListener { startVoice(input, answer, isVera, c) }
        }, LinearLayout.LayoutParams(0, dp(48), 1f))
        row.addView(Button(this).apply {
            text = "■ Durdur"; setTextColor(gold); background = rounded(panel, gold, 1)
            setOnClickListener {
                try { speechRecognizer?.cancel() } catch (_: Exception) {}
                isListening = false
                tts?.stop()
                answer.text = "Ses durduruldu. İstediğinde tekrar konuşabilirsin."
            }
        }, LinearLayout.LayoutParams(0, dp(48), 1f))
        p.addView(row)

        section(p, if (isVera) "HIZLI KOMUTLAR" else "KONUŞMA")
        if (isVera) {
            listOf("Feneri aç", "Wi-Fi ayarlarını aç", "WhatsApp'ı aç", "Saat") .forEach { cmd ->
                pill(p, cmd, c) { sendMessage(cmd, true, answer, c) }
            }
        } else {
            card(p, "Sohbet hafızası", "Bu oturumdaki mesajlar bağlam olarak sonraki isteklere eklenir.", c)
            card(p, "Yapay zekâ bağlantısı", if (apiUrl.isBlank()) "Ayarlar bölümünden çalışan sunucu adresini gir." else "Sunucu adresi kayıtlı: $apiUrl", c) { showSettings() }
        }
    }

    private fun speak(text: String) {
        if (text.isBlank()) return
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "aurora_reply")
    }

    private fun sendMessage(message: String, isVera: Boolean, answer: TextView, color: Int) {
        if (message.isBlank()) {
            answer.text = "Önce bir mesaj yaz veya mikrofonla konuş."
            return
        }
        tts?.stop()
        if (isVera) {
            val reply = quickReply(message)
            answer.text = reply
            conversation.add(JSONObject().put("role", "user").put("content", message))
            conversation.add(JSONObject().put("role", "assistant").put("content", reply))
            speak(reply)
            return
        }
        if (apiUrl.isBlank()) {
            val reply = "Mesajını aldım. Veron'un kapsamlı yanıt verebilmesi için Ayarlar bölümüne çalışan yapay zekâ sunucusunun adresini girmen gerekiyor."
            answer.text = reply
            conversation.add(JSONObject().put("role", "user").put("content", message))
            speak(reply)
            return
        }
        answer.text = "Veron düşünüyor…"
        conversation.add(JSONObject().put("role", "user").put("content", message))
        Thread {
            var connection: HttpURLConnection? = null
            try {
                var endpoint = apiUrl.trim().trimEnd('/')
                if (!endpoint.endsWith("/api/chat") && !endpoint.endsWith("/chat")) endpoint += "/api/chat"
                connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15000
                    readTimeout = 45000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    if (apiKey.isNotBlank()) setRequestProperty("Authorization", "Bearer $apiKey")
                }
                val history = JSONArray()
                conversation.takeLast(20).forEach { history.put(it) }
                val systemPrompt = "Sen Veron'sun: Türkçe konuşan, dikkatli, inisiyatif alan kişisel asistansın. Kullanıcının mesajını ve önceki konuşmayı analiz et; sadece cevap vermekle kalma, uygunsa 1-3 somut fikir, olası risk veya sonraki adım öner. Bilmediğin şeyi uydurma. Kullanıcının onayı olmadan arama, mesaj gönderme, satın alma veya dış dünyada işlem yaptığını iddia etme. Kısa ama anlamlı konuş; sesli okunmaya uygun doğal Türkçe kullan."
                val payload = JSONObject().put("message", message).put("assistant", "veron").put("systemPrompt", systemPrompt).put("proactiveSuggestions", true).put("history", history)
                OutputStreamWriter(connection.outputStream, Charsets.UTF_8).use { it.write(payload.toString()) }
                val code = connection.responseCode
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                if (code !in 200..299) throw Exception("Sunucu HTTP $code: ${body.take(250)}")
                val json = JSONObject(body)
                val reply = json.optString("reply").ifBlank {
                    json.optString("response").ifBlank {
                        json.optString("message").ifBlank {
                            json.optJSONObject("data")?.optString("reply")
                                ?: json.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content")
                                ?: "Sunucu yanıt verdi ama yanıt metni tanınamadı."
                        }
                    }
                }
                conversation.add(JSONObject().put("role", "assistant").put("content", reply))
                mainHandler.post { answer.text = reply; speak(reply) }
            } catch (e: Exception) {
                val err = "Veron sunucusuna bağlanamadı: ${e.message ?: "bağlantı hatası"}"
                mainHandler.post { answer.text = err }
            } finally { connection?.disconnect() }
        }.start()
    }

    private fun quickReply(msg: String): String {
        val s = msg.lowercase(Locale("tr", "TR"))
        return when {
            "fener" in s && ("aç" in s || "yak" in s) -> { if (!flashlightOn) toggleFlashlight(); "Feneri açma komutunu uyguladım." }
            "fener" in s && ("kapat" in s || "söndür" in s) -> { if (flashlightOn) toggleFlashlight(); "Feneri kapatma komutunu uyguladım." }
            "whatsapp" in s -> { launchApp("WhatsApp"); "WhatsApp açılıyor." }
            "chrome" in s -> { launchApp("Chrome"); "Chrome açılıyor." }
            "kamera" in s -> { launchApp("Kamera"); "Kamera açılıyor." }
            "galeri" in s || "fotoğraf" in s -> { launchApp("Galeri"); "Galeri açılıyor." }
            "müzik" in s || "youtube music" in s -> { launchApp("Müzik"); "Müzik uygulaması açılıyor." }
            "telefon" in s || "ara" == s -> { launchApp("Telefon"); "Telefon uygulaması açılıyor." }
            ("wifi" in s || "wi-fi" in s) && ("aç" in s || "ayar" in s) -> { startActivity(Intent(android.provider.Settings.ACTION_WIFI_SETTINGS)); "Wi-Fi ayarları açılıyor." }
            "bluetooth" in s -> { startActivity(Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS)); "Bluetooth ayarları açılıyor." }
            "saat" in s || "kaç" in s && "saat" in s -> "Saat ${java.text.SimpleDateFormat("HH:mm", Locale("tr", "TR")).format(java.util.Date())}."
            "durdur" in s || "sus" in s -> { tts?.stop(); "Tamam, durdum." }
            else -> "Bu komutu henüz tanımıyorum. Fener, saat, Wi-Fi, Bluetooth, Chrome, kamera, galeri, WhatsApp veya müzik diyebilirsin."
        }
    }

    private fun showSettings() {
        val p=base("Ayarlar","YB Aurora • Bağlantı ve izinler")
        section(p,"VERON YAPAY ZEKÂ BAĞLANTISI")
        val url=EditText(this).apply { hint="API sunucu adresi"; setText(apiUrl); setTextColor(Color.WHITE); setHintTextColor(0xff8ba2b9.toInt()); background=rounded(panel,blue,1); setPadding(dp(12),dp(10),dp(12),dp(10)) }
        val key=EditText(this).apply { hint="API anahtarı (isteğe bağlı)"; setText(apiKey); setTextColor(Color.WHITE); setHintTextColor(0xff8ba2b9.toInt()); inputType=129; background=rounded(panel,blue,1); setPadding(dp(12),dp(10),dp(12),dp(10)) }
        p.addView(url); p.addView(key)
        pill(p,"Kaydet",blue) { apiUrl=url.text.toString(); apiKey=key.text.toString(); getSharedPreferences("aurora",0).edit().putString("url",apiUrl).putString("key",apiKey).apply(); Toast.makeText(this,"Ayarlar kaydedildi",Toast.LENGTH_SHORT).show() }
        section(p,"GELEN ARAMA / VERA")
        card(p,"Vera'yı varsayılan telefon uygulaması yap", "Android telefon rolünü vermen gerekir. Bu, gelen arama ekranını ve yanıtla/reddet işlemlerini etkinleştirmek için gereklidir.", gold)
        pill(p,"Vera arama rolünü etkinleştir", gold) { requestDialerRole() }
        val autoAnswer = getSharedPreferences("aurora", 0).getBoolean("auto_answer", false)
        pill(p, if (autoAnswer) "Otomatik yanıt: AÇIK (dokun kapat)" else "Otomatik yanıt: KAPALI (dokun aç)", gold) {
            val next = !getSharedPreferences("aurora", 0).getBoolean("auto_answer", false)
            getSharedPreferences("aurora", 0).edit().putBoolean("auto_answer", next).apply()
            Toast.makeText(this, if (next) "Vera otomatik yanıtlamayı açtı. İstediğinde buradan kapatabilirsin." else "Vera otomatik yanıtlamayı kapattı.", Toast.LENGTH_LONG).show()
            showSettings()
        }
        card(p,"Arama sesi hakkında","Vera, izin verilen varsayılan telefon uygulaması rolüyle aramayı yanıtlayabilir. Android normal uygulamalara yapay zekâ sesini karşı tarafın telefon hattına doğrudan aktarma veya karşı tarafın sesini serbestçe kaydetme izni vermez. Vera'nın sesli selamı bu sürümde cihazında duyulur; karşı tarafın duyacağı garanti edilemez.",gold)
        section(p,"UYGULAMA HAKKINDA")
        card(p,"Veron'un fikir üretmesi","Veron, yapılandırılmış sunucuya önceki mesajlarla birlikte analiz ve öneri talimatı gönderir. Kapsamlı yanıtlar için Ayarlar'da çalışan bir yapay zekâ sunucusu gerekir.",blue)
        card(p,"İzinler","Mikrofon ve kamera/fener izinleri gerektiğinde Android tarafından istenir.",blue)
    }

    private fun requestDialerRole() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roleManager = getSystemService(RoleManager::class.java)
            if (roleManager.isRoleAvailable(RoleManager.ROLE_DIALER)) {
                if (roleManager.isRoleHeld(RoleManager.ROLE_DIALER)) {
                    Toast.makeText(this, "Vera zaten varsayılan telefon uygulaması.", Toast.LENGTH_LONG).show()
                } else {
                    startActivityForResult(roleManager.createRequestRoleIntent(RoleManager.ROLE_DIALER), 501)
                }
            } else {
                Toast.makeText(this, "Bu Android sürümünde telefon uygulaması rolü kullanılamıyor.", Toast.LENGTH_LONG).show()
            }
        } else {
            Toast.makeText(this, "Bu Android sürümü için varsayılan telefon uygulaması Ayarlar'dan seçilmeli.", Toast.LENGTH_LONG).show()
            startActivity(Intent(android.provider.Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS))
        }
    }

    private fun launchApp(label:String) {
        val pkg=when {
            "WhatsApp" in label -> "com.whatsapp"
            "Chrome" in label -> "com.android.chrome"
            "Kamera" in label -> "com.android.camera"
            "Galeri" in label -> "com.google.android.apps.photos"
            "Müzik" in label -> "com.google.android.apps.youtube.music"
            else -> null
        }
        if(pkg!=null) {
            val intent=packageManager.getLaunchIntentForPackage(pkg)
            if(intent!=null) startActivity(intent) else Toast.makeText(this,"Bu uygulama telefonda bulunamadı.",Toast.LENGTH_SHORT).show()
        } else if("Telefon" in label) {
            startActivity(Intent(Intent.ACTION_DIAL))
        } else {
            startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING))
        }
    }

    private fun toggleFlashlight() {
        if(cameraId==null) { Toast.makeText(this,"Bu cihazda fener bulunamadı.",Toast.LENGTH_SHORT).show(); return }
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.CAMERA),22); return
        }
        try {
            flashlightOn=!flashlightOn
            (getSystemService(Context.CAMERA_SERVICE) as CameraManager).setTorchMode(cameraId!!,flashlightOn)
            Toast.makeText(this,if(flashlightOn) "Fener açık" else "Fener kapalı",Toast.LENGTH_SHORT).show()
        } catch(e:Exception) { flashlightOn=false; Toast.makeText(this,"Fener açılamadı: ${e.message}",Toast.LENGTH_LONG).show() }
    }

    private fun startVoice(input: EditText, answer: TextView, isVera: Boolean, color: Int) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingInput = input; pendingAnswer = answer; pendingIsVera = isVera; pendingColor = color
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 23)
            answer.text = "Mikrofon izni gerekiyor. İzin verdikten sonra tekrar Konuş düğmesine bas."
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            answer.text = "Bu telefonda konuşma tanıma servisi bulunamadı. Android'de desteklenen bir konuşma tanıma servisi etkinleştirilmeli."
            return
        }
        try {
            speechRecognizer?.destroy()
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
            speechRecognizer?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { isListening = true; answer.text = "Dinliyorum… konuşabilirsin." }
                override fun onBeginningOfSpeech() { answer.text = "Seni dinliyorum…" }
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { isListening = false; answer.text = "Söylediklerini çözümlüyorum…" }
                override fun onError(error: Int) {
                    isListening = false
                    answer.text = when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH -> "Konuşmanı anlayamadım. Bir daha deneyebilir misin?"
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Konuşma tanıma için ağ bağlantısı gerekiyor."
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Mikrofon izni verilmedi."
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Mikrofon meşgul. Durdurup tekrar dene."
                        else -> "Ses tanıma başarısız oldu (kod $error). Tekrar deneyebilirsin."
                    }
                }
                override fun onResults(results: Bundle?) {
                    isListening = false
                    val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    if (spoken.isNotBlank()) {
                        input.setText(spoken)
                        sendMessage(spoken, isVera, answer, color)
                    } else answer.text = "Konuşma algılanmadı. Tekrar dene."
                }
                override fun onPartialResults(partialResults: Bundle?) {
                    val partial = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (!partial.isNullOrBlank()) answer.text = "Duyduğum: $partial"
                }
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "tr-TR")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_PROMPT, if (isVera) "Vera'ya komutunu söyle" else "Veron'a mesajını söyle")
            }
            pendingInput = input; pendingAnswer = answer; pendingIsVera = isVera; pendingColor = color
            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            isListening = false
            answer.text = "Mikrofon başlatılamadı: ${e.message ?: "bilinmeyen hata"}"
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 23 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Mikrofon izni verildi. Konuş düğmesine tekrar bas.", Toast.LENGTH_LONG).show()
        }
        if (requestCode == 22 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            toggleFlashlight()
        }
    }

    override fun onDestroy() {
        try { speechRecognizer?.cancel(); speechRecognizer?.destroy() } catch (_: Exception) {}
        speechRecognizer = null
        tts?.stop(); tts?.shutdown(); tts = null
        super.onDestroy()
    }

    private fun rounded(color:Int,stroke:Int,width:Int):GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius=dp(16).toFloat(); setStroke(dp(width),stroke)
    }
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
}
