YB AURORA — ANDROID UYGULAMA KAYNAK PROJESİ
================================================

Bu paket Android Studio'da açılmak ve APK olarak derlenmek üzere hazırlanmış yerel Android uygulama kaynak kodudur; web önizlemesi değildir.

İÇERİK
- YB Aurora koyu cam / elektrik mavisi / altın temalı Android arayüzü
- Ana ekran, Veron, Vera, kontrol merkezi ve ayarlar
- Fener: kamera izni verildiğinde gerçek Android fenerini açıp kapatır
- Wi-Fi, Bluetooth, ekran, ses ve uçak modu için Android sistem ayarlarına geçiş
- Telefon arama ekranına geçiş ve telefondaki bazı uygulamaları açma
- Türkçe ses tanıma isteği (cihazda bir konuşma tanıma servisi bulunmasına bağlı)

DERLEME
1. Bilgisayarda Android Studio kurun.
2. Bu ZIP dosyasını çıkarın.
3. Android Studio > Open > çıkarılan YB_Aurora_Android klasörünü seçin.
4. Gradle senkronizasyonunun tamamlanmasını bekleyin.
5. Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Üretilen APK'yı Android telefonunuza aktarın ve kurun.

ÖNEMLİ SINIRLAR
- Bu ortamda Android SDK/Gradle kurulu olmadığından hazır APK derlenemedi.
- Veron'un gerçek yapay zekâ yanıtı için çalışan backend entegrasyonu gerekir; bu sürümde API adresi alanları ayar ekranında bulunur ancak ağ isteği henüz bağlanmamıştır.
- Vera'nın gelen aramayı otomatik cevaplaması, arayan sesini dinlemesi ve Veron'a özet aktarması henüz uygulanmamıştır. Bu, varsayılan bir uygulamanın tek başına yapamayacağı; rol, izinler ve Android sürümüne uygun Telecom/CallScreening altyapısı gerektiren bir sonraki geliştirme aşamasıdır.
- HTML prototipinden farklı olarak bu paket yerel Android kaynak projesidir; yine de tamamlanmış APK veya bütün özellikleri etkin nihai ürün olarak değerlendirilmemelidir.
