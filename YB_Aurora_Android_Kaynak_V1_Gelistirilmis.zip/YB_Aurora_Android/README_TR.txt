YB AURORA — ANDROID KAYNAK PAKETİ (V1)
======================================

Bu paket, mevcut YB Aurora Android kaynaklarının ilk geliştirme sürümüdür.
Bilgisayar gerektirmeyen iş akışı hedeflenmiştir: ZIP'i telefondan GitHub deposuna
yükleyebilir ve GitHub Actions gibi bir bulut derleme akışı kurabilirsiniz.
Bu ZIP kendi başına APK değildir.

İÇERİK
- Android/Kotlin arayüzü: Ana ekran, Veron, Vera, kontrol merkezi, ayarlar.
- Vera için temel yerel komutlar: fener, Wi-Fi ayarları, WhatsApp, saat.
- Veron için OpenAI-uyumlu Chat Completions API isteği.
- API adresi ve anahtar uygulama Ayarları ekranından cihaza kaydedilebilir.
- Türkçe konuşma tanıma, cihazda uygun bir tanıma servisi bulunmasına bağlıdır.

VERON API BAĞLANTISI
Ayarlar ekranına tam bir OpenAI-uyumlu Chat Completions endpoint adresi girin.
Örnek biçim: https://SUNUCUNUZ.example/v1/chat/completions
Model adı şu an kaynak kodunda gpt-4o-mini olarak ayarlanmıştır; kullandığınız
sunucu başka bir model gerektiriyorsa MainActivity.kt içindeki "model" değerini
değiştirin. Bu örnek Google Gemini kullanmaz. API anahtarını kaynak koda gömmeyin.
Anahtarı cihaza kaydetmek yine de cihazdaki uygulama verilerine erişen kişilere
karşı tam güvenlik sağlamaz; üretim sürümünde anahtarı bir backend üzerinden
saklamak daha güvenlidir.

TELEFONDAN DERLEME
1. ZIP'i telefonda indir ve çıkar.
2. Proje dosyalarını GitHub'daki YB-Aurora-App deposuna yükle.
3. GitHub Actions için Android/Gradle derleme iş akışı ekle ve çalıştır.
4. Derleme başarılı olursa Actions artefaktlarından APK'yı indir.
5. APK'yı kurmadan önce Android'in izin/kurulum uyarılarını incele.

SINIRLAR / DOĞRULAMA
- Bu kaynak paketi burada Android SDK ile derlenmedi; APK'nın derlendiği veya
  OMIX O1 Icon üzerinde çalıştığı doğrulanmış değildir.
- API çağrısı OpenAI-uyumlu Chat Completions biçimi bekler; herhangi bir API URL'si
  otomatik olarak uyumlu değildir.
- Sürekli arka plan dinleme, asistan konuşmasını kesme, telefon aramalarını otomatik
  yanıtlama, arayan sesini işleme, sistem UI/ROM değiştirme bu sürümde tamamlanmış
  değildir.
- Android'in güvenlik kısıtları nedeniyle Wi-Fi/uçak modu gibi bazı ayarlar doğrudan
  değiştirilemez; ilgili sistem ayarları açılır.
- Özel ROM/bootloader işlemlerine cihaz uyumluluğu doğrulanmadan girişmeyin.
