plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.yb.aurora"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.yb.aurora"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
