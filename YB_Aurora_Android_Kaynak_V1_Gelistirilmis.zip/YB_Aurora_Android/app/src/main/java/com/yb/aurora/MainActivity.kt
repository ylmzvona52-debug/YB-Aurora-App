package com.yb.aurora

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.graphics.drawable.GradientDrawable
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.io.OutputStreamWriter
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val bg = Color.rgb(3, 8, 17)
    private val panel = Color.rgb(8, 19, 33)
    private val blue = Color.rgb(51, 198, 255)
    private val gold = Color.rgb(236, 184, 88)
    private var flashlightOn = false
    private var cameraId: String? = null
    private lateinit var root: LinearLayout
    private var apiUrl = ""
    private var apiKey = ""
    private var voiceInput: EditText? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        try {
            val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            cameraId = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
        } catch (_: Exception) {}
        val prefs = getSharedPreferences("aurora", 0)
        apiUrl = prefs.getString("url", "") ?: ""
        apiKey = prefs.getString("key", "") ?: ""
        showHome()
    }

    private fun base(title: String, subtitle: String? = null): LinearLayout {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(14))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(2, 7, 15), Color.rgb(7, 18, 32), Color.rgb(3, 8, 17)))
        }
        val sc = ScrollView(this)
        val inner = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0,0,0,dp(12)) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val mark = TextView(this).apply { text = "Ⅴ  YB"; textSize = 21f; setTextColor(gold); setPadding(0,0,dp(12),0) }
        header.addView(mark)
        val spacer = Space(this); header.addView(spacer, LinearLayout.LayoutParams(0,1f))
        header.addView(TextView(this).apply { text = "◉  ◉  ▰"; textSize = 13f; setTextColor(blue) })
        inner.addView(header)
        inner.addView(TextView(this).apply {
            text = title; textSize = 28f; setTextColor(Color.WHITE); setPadding(0,dp(20),0,dp(2)); typeface = android.graphics.Typeface.create("sans-serif-light",0)
        })
        if (subtitle != null) inner.addView(TextView(this).apply { text=subtitle; textSize=13f; setTextColor(0xff9fb6cc.toInt()); setPadding(0,0,0,dp(14)) })
        val line = View(this).apply { setBackgroundColor(0x5537c8ff); layoutParams=LinearLayout.LayoutParams(-1,dp(1)) }
        inner.addView(line)
        sc.addView(inner)
        root.addView(sc, LinearLayout.LayoutParams(-1,0,1f))
        val nav = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER; setPadding(0,dp(10),0,0) }
        listOf("⌂" to "Ana", "◉" to "Veron", "ϟ" to "Vera", "▦" to "Kontrol", "⚙" to "Ayarlar").forEach { (ic, label) ->
            nav.addView(Button(this).apply {
                text="$ic\n$label"; textSize=10f; setTextColor(if(label=="Vera") gold else blue)
                background = rounded(panel, blue, 1)
                setOnClickListener { when(label) { "Ana"->showHome(); "Veron"->showAssistant(false); "Vera"->showAssistant(true); "Kontrol"->showControl(); else->showSettings() } }
            }, LinearLayout.LayoutParams(0,dp(54),1f).apply { setMargins(dp(3),0,dp(3),0) })
        }
        root.addView(nav)
        setContentView(root)
        return inner
    }

    private fun section(parent: LinearLayout, title: String) {
        parent.addView(TextView(this).apply { text=title; textSize=17f; setTextColor(gold); setPadding(0,dp(18),0,dp(8)) })
    }
    private fun card(parent: LinearLayout, title: String, detail: String, color: Int = blue, action: (() -> Unit)? = null) {
        val box = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(14),dp(12),dp(14),dp(12)); background=rounded(panel,color,1) }
        box.addView(TextView(this).apply { text=title; textSize=16f; setTextColor(Color.WHITE) })
        box.addView(TextView(this).apply { text=detail; textSize=12f; setTextColor(0xffa8bed1.toInt()); setPadding(0,dp(4),0,0) })
        if(action!=null) box.setOnClickListener { action() }
        val lp=LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,dp(5),0,dp(5)); parent.addView(box,lp)
    }
    private fun pill(parent: LinearLayout, text: String, color: Int=blue, action: ()->Unit) {
        parent.addView(Button(this).apply { this.text=text; textSize=13f; setTextColor(color); background=rounded(panel,color,1); setOnClickListener { action() } },
            LinearLayout.LayoutParams(-1,dp(48)).apply { setMargins(0,dp(4),0,dp(4)) })
    }

    private fun showHome() {
        val p=base("22:45", "17 Ekim • YB AURORA  /  Gece sürüş modu")
        p.addView(TextView(this).apply {
            text="        ✦           ☾\n\n      ╱╲   ✧   ╱╲\n   ╱╲╱  ╲____╱  ╲╱╲\n      ━━━━━━━━━━━\n       ◉  YOL  ◉\n\n   YOL, VARIŞTAN DAHA DEĞERLİDİR.\n        Çünkü yolda insan kendini bulur."
            gravity=Gravity.CENTER; textSize=17f; setTextColor(0xffd5eaff.toInt()); setPadding(0,dp(14),0,dp(18))
        })
        val orb=TextView(this).apply {
            text="◉\nV E R O N\n\nMavi ışıklı ana asistan"; gravity=Gravity.CENTER; textSize=19f; setTextColor(blue)
            background=rounded(Color.rgb(5,22,40),blue,2); setPadding(dp(12),dp(18),dp(12),dp(18))
            setOnClickListener { showAssistant(false) }
        }
        p.addView(orb,LinearLayout.LayoutParams(-1,dp(142)).apply { setMargins(0,dp(5),0,dp(5)) })
        val v=TextView(this).apply {
            text="ϟ  V E R A\nAltın ışıklı hızlı asistan"; gravity=Gravity.CENTER; textSize=17f; setTextColor(gold)
            background=rounded(Color.rgb(28,20,8),gold,2); setPadding(dp(10),dp(12),dp(10),dp(12))
            setOnClickListener { showAssistant(true) }
        }
        p.addView(v,LinearLayout.LayoutParams(-1,dp(92)).apply { setMargins(0,dp(5),0,dp(12)) })
        section(p,"UYGULAMALAR")
        val apps= listOf("☎  Telefon" to "Telefon uygulamasını aç", "◉  Chrome" to "Chrome'u aç", "◎  Kamera" to "Kamera'yı aç", "▧  Galeri" to "Fotoğrafları aç", "◉  WhatsApp" to "WhatsApp sohbet görünümü", "▤  Mesajlar" to "Mesajlar", "♫  Müzik" to "Müzik")
        apps.forEach { (a,d) -> card(p,a,d) { launchApp(a) } }
        pill(p,"KONTROL MERKEZİ",blue) { showControl() }
    }

    private fun showControl() {
        val p=base("Kontrol Merkezi","3. sürüm düzeni • Sistem izinlerine göre çalışır")
        section(p,"BİLDİRİMLER")
        card(p,"Veron","Ana asistan hazır • Mavi sistem",blue) { showAssistant(false) }
        card(p,"Vera","Hızlı komutlar • Altın sistem",gold) { showAssistant(true) }
        card(p,"WhatsApp","Uygulama sohbetlerine geçiş",0xff42d9b5.toInt()) { launchApp("WhatsApp") }
        section(p,"TELEFON ARAÇLARI")
        pill(p, if(flashlightOn) "☼  FENERİ KAPAT" else "☼  FENERİ AÇ", gold) { toggleFlashlight() }
        pill(p,"◉  Wi-Fi ayarları",blue) { startActivity(Intent(android.provider.Settings.ACTION_WIFI_SETTINGS)) }
        pill(p,"ϟ  Bluetooth ayarları",blue) { startActivity(Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS)) }
        pill(p,"▰  Ekran / parlaklık ayarları",blue) { startActivity(Intent(android.provider.Settings.ACTION_DISPLAY_SETTINGS)) }
        pill(p,"◐  Ses ayarları",blue) { startActivity(Intent(android.provider.Settings.ACTION_SOUND_SETTINGS)) }
        pill(p,"✈  Uçak modu ayarları",blue) { startActivity(Intent(android.provider.Settings.ACTION_AIRPLANE_MODE_SETTINGS)) }
        card(p,"Not","Android güvenliği nedeniyle bazı sistem anahtarları doğrudan değiştirilemez; ilgili sistem ayarı açılır.",gold)
    }

    private fun showAssistant(isVera: Boolean) {
        val c=if(isVera) gold else blue
        val p=base(if(isVera) "VERA" else "VERON", if(isVera) "Hızlı asistan • kısa komutlar" else "Ana asistan • araştırma ve kapsamlı görevler")
        p.addView(TextView(this).apply { text=if(isVera) "ϟ" else "◉"; gravity=Gravity.CENTER; textSize=68f; setTextColor(c); background=rounded(panel,c,2); setPadding(0,dp(8),0,dp(8)) },
            LinearLayout.LayoutParams(-1,dp(118)).apply { setMargins(0,dp(14),0,dp(12)) })
        val answer=TextView(this).apply { text=if(isVera) "Vera hazır. Hızlı komutunu yaz veya sesle söyle." else "Veron hazır. Araştırma, analiz ve görevler için mesajını yaz."; setTextColor(Color.WHITE); textSize=15f; setPadding(dp(10),dp(10),dp(10),dp(10)) }
        p.addView(answer)
        val input=EditText(this).apply { hint="Buraya yaz…"; setHintTextColor(0xff8ba2b9.toInt()); setTextColor(Color.WHITE); setSingleLine(false); background=rounded(panel,c,1); setPadding(dp(12),dp(10),dp(12),dp(10)) }
        p.addView(input,LinearLayout.LayoutParams(-1,-2).apply { setMargins(0,dp(8),0,dp(8)) })
        val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        row.addView(Button(this).apply { text="Gönder"; setTextColor(c); background=rounded(panel,c,1); setOnClickListener {
            val msg=input.text.toString().trim()
            if (msg.isEmpty()) answer.text = "Önce bir mesaj yaz."
            else if (isVera) answer.text = quickReply(msg)
            else {
                answer.text = "Veron yanıt hazırlıyor…"
                requestVeronReply(msg, answer)
            }
        } },LinearLayout.LayoutParams(0,dp(48),1f))
        row.addView(Button(this).apply { text="🎙"; setTextColor(c); background=rounded(panel,c,1); setOnClickListener { startVoice(input) } },LinearLayout.LayoutParams(dp(64),dp(48)))
        p.addView(row)
        if(!isVera) {
            section(p,"HIZLI GÖREVLER")
            listOf("Araştırma yap","Plan oluştur","Metni özetle","Feneri aç").forEach { cmd -> pill(p,cmd,c) { input.setText(cmd); if(cmd=="Feneri aç") toggleFlashlight() } }
        } else {
            section(p,"HIZLI KOMUTLAR")
            listOf("Feneri aç","Wi-Fi ayarlarını aç","WhatsApp'ı aç","Saat").forEach { cmd -> pill(p,cmd,c) {
                when(cmd) { "Feneri aç" -> { toggleFlashlight(); answer.text="Fener komutu işlendi." }; "Wi-Fi ayarlarını aç" -> startActivity(Intent(android.provider.Settings.ACTION_WIFI_SETTINGS)); "WhatsApp'ı aç" -> launchApp("WhatsApp"); else -> answer.text=java.text.SimpleDateFormat("HH:mm",Locale("tr","TR")).format(java.util.Date()) }
            } }
        }
    }


    /**
     * apiUrl must be an OpenAI-compatible chat-completions endpoint, for example:
     * https://YOUR-SERVER.example/v1/chat/completions
     * Keep provider keys out of source code; save them only in Settings on the device.
     */
    private fun requestVeronReply(message: String, answer: TextView) {
        val endpoint = apiUrl.trim()
        val key = apiKey.trim()
        if (endpoint.isBlank()) {
            answer.text = "Veron henüz bir yapay zekâ sunucusuna bağlı değil. Ayarlar bölümüne OpenAI uyumlu /v1/chat/completions adresini ve API anahtarını gir."
            return
        }
        thread(name = "veron-api-request") {
            var connection: HttpURLConnection? = null
            try {
                connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15000
                    readTimeout = 30000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    if (key.isNotBlank()) setRequestProperty("Authorization", "Bearer $key")
                }
                val body = JSONObject().apply {
                    put("model", "gpt-4o-mini")
                    put("messages", JSONArray().put(JSONObject().put("role", "system").put("content",
                        "Sen Veron'sun: Türkçe konuşan, açık ve güvenli kişisel asistansın. Android sisteminde yapamadığın işlemleri yaptığını iddia etme."))
                        .put(JSONObject().put("role", "user").put("content", message)))
                    put("temperature", 0.6)
                }.toString()
                OutputStreamWriter(connection.outputStream, Charsets.UTF_8).use { it.write(body) }
                val code = connection.responseCode
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val responseText = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                if (code !in 200..299) throw IllegalStateException("Sunucu HTTP $code: ${responseText.take(350)}")
                val json = JSONObject(responseText)
                val reply = json.optJSONArray("choices")?.optJSONObject(0)
                    ?.optJSONObject("message")?.optString("content").orEmpty()
                if (reply.isBlank()) throw IllegalStateException("Sunucudan yanıt metni alınamadı.")
                runOnUiThread { answer.text = reply }
            } catch (e: Exception) {
                runOnUiThread {
                    answer.text = "Veron bağlantı hatası: ${e.message ?: "Bilinmeyen hata"}. API adresini, anahtarı ve internet bağlantısını kontrol et."
                }
            } finally {
                connection?.disconnect()
            }
        }
    }

    private fun quickReply(msg:String):String {
        val s=msg.lowercase(Locale("tr","TR"))
        return when {
            "fener" in s -> { toggleFlashlight(); "Fener komutu işlendi." }
            "whatsapp" in s -> { launchApp("WhatsApp"); "WhatsApp açılıyor." }
            "wifi" in s || "wi-fi" in s -> { startActivity(Intent(android.provider.Settings.ACTION_WIFI_SETTINGS)); "Wi-Fi ayarları açılıyor." }
            "saat" in s -> java.text.SimpleDateFormat("HH:mm",Locale("tr","TR")).format(java.util.Date())
            else -> "Bu hızlı komut için henüz bir eylem tanımlı değil."
        }
    }

    private fun showSettings() {
        val p=base("Ayarlar","YB Aurora • Bağlantı ve izinler")
        section(p,"VERON YAPAY ZEKÂ BAĞLANTISI")
        val url=EditText(this).apply { hint="API sunucu adresi"; setText(apiUrl); setTextColor(Color.WHITE); setHintTextColor(0xff8ba2b9.toInt()); background=rounded(panel,blue,1); setPadding(dp(12),dp(10),dp(12),dp(10)) }
        val key=EditText(this).apply { hint="API anahtarı (isteğe bağlı)"; setText(apiKey); setTextColor(Color.WHITE); setHintTextColor(0xff8ba2b9.toInt()); inputType=129; background=rounded(panel,blue,1); setPadding(dp(12),dp(10),dp(12),dp(10)) }
        p.addView(url); p.addView(key)
        pill(p,"Kaydet",blue) { apiUrl=url.text.toString(); apiKey=key.text.toString(); getSharedPreferences("aurora",0).edit().putString("url",apiUrl).putString("key",apiKey).apply(); Toast.makeText(this,"Ayarlar kaydedildi",Toast.LENGTH_SHORT).show() }
        section(p,"UYGULAMA HAKKINDA")
        card(p,"Gerçek Android uygulaması","Bu kaynak Android Studio'da APK olarak derlenmek üzere hazırlanmıştır. Gelen aramayı otomatik yanıtlama, arayanın sesini dinleme ve Veron'a aktarma henüz etkinleştirilmiş değildir.",gold)
        card(p,"İzinler","Mikrofon ve kamera/fener izinleri gerektiğinde Android tarafından istenir.",blue)
    }

    private fun launchApp(label:String) {
        val pkg=when {
            "WhatsApp" in label -> "com.whatsapp"
            "Chrome" in label -> "com.android.chrome"
            "Kamera" in label -> "com.android.camera"
            "Galeri" in label -> "com.google.android.apps.photos"
            "Müzik" in label -> "com.google.android.apps.youtube.music"
            else -> null
        }
        if(pkg!=null) {
            val intent=packageManager.getLaunchIntentForPackage(pkg)
            if(intent!=null) startActivity(intent) else Toast.makeText(this,"Bu uygulama telefonda bulunamadı.",Toast.LENGTH_SHORT).show()
        } else if("Telefon" in label) {
            startActivity(Intent(Intent.ACTION_DIAL))
        } else {
            startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING))
        }
    }

    private fun toggleFlashlight() {
        if(cameraId==null) { Toast.makeText(this,"Bu cihazda fener bulunamadı.",Toast.LENGTH_SHORT).show(); return }
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.CAMERA),22); return
        }
        try {
            flashlightOn=!flashlightOn
            (getSystemService(Context.CAMERA_SERVICE) as CameraManager).setTorchMode(cameraId!!,flashlightOn)
            Toast.makeText(this,if(flashlightOn) "Fener açık" else "Fener kapalı",Toast.LENGTH_SHORT).show()
        } catch(e:Exception) { flashlightOn=false; Toast.makeText(this,"Fener açılamadı: ${e.message}",Toast.LENGTH_LONG).show() }
    }

    private fun startVoice(input:EditText) {
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.RECORD_AUDIO),23); return
        }
        voiceInput = input
        try {
            val i=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE,"tr-TR"); putExtra(RecognizerIntent.EXTRA_PROMPT,"Komutunu söyle")
            }
            startActivityForResult(i,24)
        } catch(_:Exception) { Toast.makeText(this,"Bu cihazda konuşma tanıma servisi bulunamadı.",Toast.LENGTH_LONG).show() }
    }
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==24 && resultCode==Activity.RESULT_OK) {
            val spoken=data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if(!spoken.isNullOrBlank()) {
                voiceInput?.setText(spoken)
                voiceInput?.setSelection(spoken.length)
                if (voiceInput == null) Toast.makeText(this,"Algılanan komut: $spoken",Toast.LENGTH_LONG).show()
            }
        }
    }
    private fun rounded(color:Int,stroke:Int,width:Int):GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius=dp(16).toFloat(); setStroke(dp(width),stroke)
    }
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
}
